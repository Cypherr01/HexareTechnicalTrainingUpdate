package com.project.carrental.dto;

import lombok.Data;
import lombok.Getter;
import lombok.Setter;

@Data
public class SearchCarDto {

    private String brand;

    private String type;

    private String transmission;

    private String color;

	public String getBrand() {
		return brand;
	}

	public void setBrand(String brand) {
		this.brand = brand;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public String getTransmission() {
		return transmission;
	}

	public void setTransmission(String transmission) {
		this.transmission = transmission;
	}

	public String getColor() {
		return color;
	}

	public void setColor(String color) {
		this.color = color;
	}
    
    

}