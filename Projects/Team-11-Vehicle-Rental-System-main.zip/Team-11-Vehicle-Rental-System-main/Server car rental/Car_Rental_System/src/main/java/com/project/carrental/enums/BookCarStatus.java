package com.project.carrental.enums;

public enum BookCarStatus {

    PENDING,
    APPROVED,
    REJECTED

}
