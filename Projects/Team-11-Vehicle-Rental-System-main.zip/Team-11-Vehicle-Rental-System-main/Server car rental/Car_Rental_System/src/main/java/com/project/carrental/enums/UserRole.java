package com.project.carrental.enums;

public enum UserRole {
    ADMIN,
    CUSTOMER,
}
