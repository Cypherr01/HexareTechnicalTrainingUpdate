

export const environment = {
  production: false,
  BASIC_URL : "http://localhost:8080/"
};

